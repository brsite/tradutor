$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Get-Clipboard | Set-Content -Path "music.txt" -Encoding utf8
(Get-Content -Path "music.txt" -Raw -Encoding utf8) -replace '[//]', '' -replace 'alexatocar', 'Entendi, tocando' | Set-Content -Path "music2.txt" -Encoding utf8
(Get-Content -Path "music.txt" -Raw -Encoding utf8) -replace '[//]', '' -replace 'alexatocar', '' | Set-Content -Path "music.txt" -Encoding utf8
$music = Get-Content -Path "music.txt" -Raw -Encoding utf8
$music | Set-Content -Path "C:\TRADUTOR\Scripts\YouTube\musicnome.txt" -Encoding utf8
Start-Process -NoNewWindow -FilePath "C:\TRADUTOR\Scripts\Youtube\musicalexa.bat"
Start-Process -NoNewWindow -FilePath "balcon.exe" -ArgumentList "-n `"Microsoft Francisca Online`" -f `music2.txt` -b 2 -v 25"
