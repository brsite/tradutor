# Define os caminhos dos arquivos
$entrada = "charadas.txt"
$saida = "charadas2.txt"

# Lê todas as linhas do arquivo de entrada
$linhas = Get-Content -Path $entrada

# Seleciona uma linha aleatória
$linhaAleatoria = Get-Random -InputObject $linhas

# Salva a linha aleatória no arquivo de saída
$linhaAleatoria | Out-File -FilePath $saida -Encoding UTF8
